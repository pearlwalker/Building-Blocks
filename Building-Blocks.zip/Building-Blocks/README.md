# Building-Blocks
IGME.201 assignment "Participation: Building Blocks"
